package com.example.servicecanard.services;

import com.example.servicecanard.entitie.Users;
import com.example.servicecanard.interfaces.Iusers;

public class ServiceUsers implements Iusers {
    Users users;
    @Override
    public Users getUsers() {
        users = new Users();
        users.setId(1);
        users.setName("Yves");
        users.setAge(24);
        users.setSexe("Masculin");

        return users;
    }
}
