package com.example.servicecanard.model;


import com.example.servicecanard.entitie.CanardEntitie;
import com.example.servicecanard.interfaces.ComportementAuVol;

public class JeNeVolePas implements ComportementAuVol {
    @Override
    public CanardEntitie comportement() {
        CanardEntitie entitie = new CanardEntitie();
        entitie.setX(200);
        entitie.setY(100);
        entitie.setW(60);
        entitie.setH(60);
        entitie.setDx(5);
        entitie.setDy(2);
        entitie.setPositionX("right");
        entitie.setPositionY("left");

        return entitie;
    }
}
