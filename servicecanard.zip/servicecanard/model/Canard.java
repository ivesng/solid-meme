package com.example.servicecanard.model;


import com.example.servicecanard.entitie.CanardEntitie;
import com.example.servicecanard.interfaces.ComportementAuVol;

public class Canard {
    private ComportementAuVol auVol;

    public Canard(ComportementAuVol auVol) {
        this.auVol = auVol;
    }


    public CanardEntitie lancerLeVol(){
      return  auVol.comportement();
    }

}
