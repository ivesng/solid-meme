package com.example.servicecanard.controlleur;

import com.example.servicecanard.entitie.CanardEntitie;
import com.example.servicecanard.entitie.Users;
import com.example.servicecanard.model.Canard;
import com.example.servicecanard.model.JeNeVolePas;
import com.example.servicecanard.model.Voler;
import com.example.servicecanard.services.ServiceUsers;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class Controlleur {

    @CrossOrigin
    @GetMapping(value = "/Comportement/{action}")
    public CanardEntitie voler(@PathVariable String action){
        System.out.println(action);
        Canard canard = new Canard(new Voler());
        List<CanardEntitie> list = new ArrayList<>();
        if (action.equals("voler"))
        {
            list.add((new Canard(new Voler())).lancerLeVol());
            return (new Canard(new Voler())).lancerLeVol();
        }
        else if (action.equals("marcher")){
           // list.add((new Canard(new JeNeVolePas())).lancerLeVol());
            return (new Canard(new JeNeVolePas())).lancerLeVol();
        }
        return null;
    }

    @CrossOrigin
    @GetMapping(value = "/Comportement/{action}")
    public Users getUsers(){
        ServiceUsers users = new ServiceUsers();
        return users.getUsers();
    }

}
