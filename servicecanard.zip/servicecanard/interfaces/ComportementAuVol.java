package com.example.servicecanard.interfaces;

import com.example.servicecanard.entitie.CanardEntitie;

public interface ComportementAuVol {
    public CanardEntitie comportement();
}
