package com.example.servicecanard.interfaces;

import com.example.servicecanard.entitie.Users;

public interface Iusers{
    public Users getUsers();
}
