package com.example.servicecanard.entitie;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CanardEntitie {
    // Position de départ
    private int y;
    private int x;
    // Dimensions de l'image disk35.gif
    private int w;
    private int h;
    // A chaque déplacement la balle bouge de
    private int dx;
    private int dy;
    private String positionX;
    private String positionY;


}
