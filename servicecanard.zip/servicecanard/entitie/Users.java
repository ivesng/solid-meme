package com.example.servicecanard.entitie;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Users {
    private int id;
    private String name;
    private int age;
    private String sexe;
}
