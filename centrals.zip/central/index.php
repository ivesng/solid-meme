<?php
    require_once ('header.php');

if (isset($_SESSION['role'])) {
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>CentralData</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="assets/vendors/jquery-bar-rating/css-stars.css" />
    <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css" />
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/demo_1/style.css" />
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/picture/central.jpeg" />
  </head>
  <body>
 <?php
        if ($_SESSION['role'] == 'admin'){ ?>
            <div class="container-scroller">
                <!-- partial:partials/_sidebar.html -->
                <nav class="sidebar sidebar-offcanvas" id="sidebar">
                    <ul class="nav">
                        <li class="nav-item nav-profile border-bottom">
                            <a href="#" class="nav-link flex-column">
                                <div class="nav-profile-image">
                                    <img src="assets/picture/central.jpeg" alt="profile" />
                                    <!--change to offline or busy as needed-->
                                </div>
                                <div class="nav-profile-text d-flex ml-0 mb-3 flex-column">
                                    <span class="font-weight-semibold mb-1 mt-2 text-center">Admin</span>
                                    <span class="text-secondary icon-sm text-center" hidden>$3499.00</span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item pt-3">


                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?page=accueil">
                                <i class="mdi mdi-compass-outline menu-icon"></i>
                                <span class="menu-title">Tableau de bord</span>
                            </a>
                        </li>


                        <li class="nav-item pt-3">
                            <a class="nav-link" href="index.php?page=gerer" >
                                <i class="mdi mdi-file-document-box menu-icon"></i>
                                <span class="menu-title">Gerer</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- partial -->
                <div class="container-fluid page-body-wrapper">
                    <!-- partial:partials/_settings-panel.html -->
                    <div id="settings-trigger"><i class="mdi mdi-settings"></i></div>
                    <div id="theme-settings" class="settings-panel">
                        <i class="settings-close mdi mdi-close"></i>
                        <p class="settings-heading">SIDEBAR SKINS</p>
                        <div class="sidebar-bg-options selected" id="sidebar-default-theme">
                            <div class="img-ss rounded-circle bg-light border mr-3"></div>Default
                        </div>
                        <div class="sidebar-bg-options" id="sidebar-dark-theme">
                            <div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark
                        </div>
                        <p class="settings-heading mt-2">HEADER SKINS</p>
                        <div class="color-tiles mx-0 px-4">
                            <div class="tiles default primary"></div>
                            <div class="tiles success"></div>
                            <div class="tiles warning"></div>
                            <div class="tiles danger"></div>
                            <div class="tiles info"></div>
                            <div class="tiles dark"></div>
                            <div class="tiles light"></div>
                        </div>
                    </div>
                    <!-- partial -->
                    <!-- partial:partials/_navbar.html -->
                    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
                        <div class="navbar-menu-wrapper d-flex align-items-stretch">
                            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                                <span class="mdi mdi-chevron-double-left"></span>
                            </button>
                            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                                <a class="navbar-brand brand-logo-mini" href="index.php"><img src="assets/images/logo-mini.svg" alt="logo" /></a>
                            </div>
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a hidden class="nav-link" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                                        <i class="mdi mdi-email-outline"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-left navbar-dropdown preview-list" aria-labelledby="messageDropdown">
                                        <h6 class="p-3 mb-0 font-weight-semibold">Messages</h6>
                                        <div class="dropdown-divider"></div>
                                        <a  hidden class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <img src="assets/images/faces/face1.jpg" alt="image" class="profile-pic">
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Mark send you a message</h6>
                                                <p class="text-gray mb-0"> 1 Minutes ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a hidden class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <img src="assets/images/faces/face6.jpg" alt="image" class="profile-pic">
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Cregh send you a message</h6>
                                                <p class="text-gray mb-0"> 15 Minutes ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <img src="assets/images/faces/face7.jpg" alt="image" class="profile-pic">
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Profile picture updated</h6>
                                                <p class="text-gray mb-0"> 18 Minutes ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <h6 class="p-3 mb-0 text-center text-primary font-13">4 new messages</h6>
                                    </div>
                                </li>
                                <li class="nav-item dropdown ml-3">
                                    <a hidden class="nav-link" id="notificationDropdown" href="#" data-toggle="dropdown">
                                        <i class="mdi mdi-bell-outline"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-left navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
                                        <h6 class="px-3 py-3 font-weight-semibold mb-0">Notifications</h6>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <div class="preview-icon bg-success">
                                                    <i class="mdi mdi-calendar"></i>
                                                </div>
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject font-weight-normal mb-0">New order recieved</h6>
                                                <p class="text-gray ellipsis mb-0"> 45 sec ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <div class="preview-icon bg-warning">
                                                    <i class="mdi mdi-settings"></i>
                                                </div>
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject font-weight-normal mb-0">Server limit reached</h6>
                                                <p class="text-gray ellipsis mb-0"> 55 sec ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <div class="preview-icon bg-info">
                                                    <i class="mdi mdi-link-variant"></i>
                                                </div>
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject font-weight-normal mb-0">Kevin karvelle</h6>
                                                <p class="text-gray ellipsis mb-0"> 11:09 PM </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <h6 class="p-3 font-13 mb-0 text-primary text-center">View all notifications</h6>
                                    </div>
                                </li>
                            </ul>
                            <ul class="navbar-nav navbar-nav-right">
                                <li hidden class="nav-item nav-logout d-none d-md-block mr-3">
                                    <a hidden class="nav-link" href="#">Status</a>
                                </li>
                                <li class="nav-item nav-logout d-none d-md-block">
                                    <a class="btn btn-sm btn-danger" href="controller/Controller.php?page=detroy">Deconnexion</a>
                                </li>

                                <li hidden class="nav-item nav-logout d-none d-lg-block">
                                    <a hidden class="nav-link" href="controller/Controller.php?page=detroy">
                                        <i class="mdi mdi-account-circle"></i>
                                    </a>
                                </li>
                            </ul>
                            <a href="controller/Controller.php?page=detroy" class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                                <span class="mdi mdi-account"></span>
                            </a>
                        </div>
                    </nav>
                    <!-- partial -->
                    <div class="main-panel">
                        <div class="content-wrapper pb-0">
                            <div class="page-header flex-wrap">
                                <div class="header-left">
                                    <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal"> Creer nouvelle chaine </button>
                                    <div id="myModal" class="modal fade" role="dialog">
                                        <div class="modal-dialog modal-lg">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-12 grid-margin stretch-card">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h4 class="card-title">Creer nouvelle chaine</h4>

                                                                <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">
                                                                    <div class="form-group">
                                                                        <label for="inputNomChaine">Nom de la chaine</label>
                                                                        <input type="text" class="form-control" id="inputNomChaine" placeholder="Nom de la chaine" name="inputNomChaine" required />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="inputFrqRadio">Frequence Radio</label>
                                                                        <input type="text" class="form-control"  id="inputFrqRadio" placeholder="Frequence Radio" name="inputFrqRadio" required/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword4">Frequence Télé</label>
                                                                        <input type="text" class="form-control" id="inputFrqTele" placeholder="Frequence Télé" name="inputFrqTele" required/>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>Logo</label>
                                                                        <input type="file" name="fichier" class="form-control" required/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="inputTelephone">Téléphone</label>
                                                                        <input type="text" class="form-control" id="inputTelephone" placeholder="Téléphone" name="inputTelephone" required/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleTextarea1">Adresse</label>
                                                                        <textarea
                                                                                class="form-control"
                                                                                name="inputAdresse" id="inputAdresse"
                                                                                rows="4"
                                                                        ></textarea>
                                                                    </div>
                                                                    <button type="submit" name="btn_creer_chaine" class="btn btn-primary mr-2"> Creer </button>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">


                                </div>
                            </div>
                            <?php
                            if (isset($_GET['page'])){
                                if ($_GET['page'] == "accueil")
                                    include ('vues/accueil.php');
                                if ($_GET['page'] == 'gerer')
                                    include ('vues/gerer.php');
                            }else{
                                include ('vues/accueil.php');
                            }


                            ?>
                        </div>
                    </div>
                </div>
            </div>

  <?php      }else if ($_SESSION['role'] == 'chaine'){ ?>
            <div class="container-scroller">
                <!-- partial:partials/_sidebar.html -->
                <nav class="sidebar sidebar-offcanvas" id="sidebar">
                    <ul class="nav">
                        <li class="nav-item nav-profile border-bottom">
                            <a href="#" class="nav-link flex-column">
                                <div class="nav-profile-image">
                                    <img src="assets/picture/<?=Chaine::AFFICHER_PHOTO($_SESSION['idusers'])?>" alt="profile" />
                                    <!--change to offline or busy as needed-->
                                </div>
                                <div class="nav-profile-text d-flex ml-0 mb-3 flex-column">
                                    <span class="font-weight-semibold mb-1 mt-2 text-center"><?=ucwords($_SESSION['login'])?></span>
                                    <span class="text-secondary icon-sm text-center" hidden>$3499.00</span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item pt-3">


                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?page=accueil">
                                <i class="mdi mdi-compass-outline menu-icon"></i>
                                <span class="menu-title">Tableau de bord</span>
                            </a>
                        </li>


                        <li class="nav-item pt-3">
                            <a class="nav-link" href="index.php?page=gerer" >
                                <i class="mdi mdi-file-document-box menu-icon"></i>
                                <span class="menu-title">Mes fichiers</span>
                            </a>
                        </li>
                        <li class="nav-item pt-3">
                            <a class="nav-link" href="index.php?page=correspondant" >
                                <i class="mdi mdi-file-document-box menu-icon"></i>
                                <span class="menu-title">Fichiers partagés</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- partial -->
                <div class="container-fluid page-body-wrapper">
                    <!-- partial:partials/_settings-panel.html -->
                    <div id="settings-trigger"><i class="mdi mdi-settings"></i></div>
                    <div id="theme-settings" class="settings-panel">
                        <i class="settings-close mdi mdi-close"></i>
                        <p class="settings-heading">SIDEBAR SKINS</p>
                        <div class="sidebar-bg-options selected" id="sidebar-default-theme">
                            <div class="img-ss rounded-circle bg-light border mr-3"></div>Default
                        </div>
                        <div class="sidebar-bg-options" id="sidebar-dark-theme">
                            <div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark
                        </div>
                        <p class="settings-heading mt-2">HEADER SKINS</p>
                        <div class="color-tiles mx-0 px-4">
                            <div class="tiles default primary"></div>
                            <div class="tiles success"></div>
                            <div class="tiles warning"></div>
                            <div class="tiles danger"></div>
                            <div class="tiles info"></div>
                            <div class="tiles dark"></div>
                            <div class="tiles light"></div>
                        </div>
                    </div>
                    <!-- partial -->
                    <!-- partial:partials/_navbar.html -->
                    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
                        <div class="navbar-menu-wrapper d-flex align-items-stretch">
                            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                                <span class="mdi mdi-chevron-double-left"></span>
                            </button>
                            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                                <a class="navbar-brand brand-logo-mini" href="index.php"><img src="assets/images/logo-mini.svg" alt="logo" /></a>
                            </div>
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="index.php?page=msg" id="messageDropdown" href="#" >
                                        <i class="mdi mdi-email-outline"></i>
                                    </a>
                                    
                                </li>
                                <li class="nav-item dropdown ml-3">
                                    <a class="nav-link" id="notificationDropdown" hidden href="#" data-toggle="dropdown">
                                        <i class="mdi mdi-bell-outline"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-left navbar-dropdown preview-list" hidden aria-labelledby="notificationDropdown">
                                        <h6 class="px-3 py-3 font-weight-semibold mb-0">Notifications</h6>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <div class="preview-icon bg-success">
                                                    <i class="mdi mdi-calendar"></i>
                                                </div>
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject font-weight-normal mb-0">New order recieved</h6>
                                                <p class="text-gray ellipsis mb-0"> 45 sec ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <div class="preview-icon bg-warning">
                                                    <i class="mdi mdi-settings"></i>
                                                </div>
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject font-weight-normal mb-0">Server limit reached</h6>
                                                <p class="text-gray ellipsis mb-0"> 55 sec ago </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item preview-item">
                                            <div class="preview-thumbnail">
                                                <div class="preview-icon bg-info">
                                                    <i class="mdi mdi-link-variant"></i>
                                                </div>
                                            </div>
                                            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                                <h6 class="preview-subject font-weight-normal mb-0">Kevin karvelle</h6>
                                                <p class="text-gray ellipsis mb-0"> 11:09 PM </p>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <h6 class="p-3 font-13 mb-0 text-primary text-center">View all notifications</h6>
                                    </div>
                                </li>
                            </ul>
                            <ul class="navbar-nav navbar-nav-right">
                                <li hidden class="nav-item nav-logout d-none d-md-block mr-3">
                                    <a class="nav-link" hidden href="#">Status</a>
                                </li>
                                <li class="nav-item nav-logout d-none d-md-block">
                                    <a href="controller/Controller.php?page=detroy" class="btn btn-sm btn-danger">Déconnexion</a>
                                </li>

                                
                            </ul>
                            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                                <span class="mdi mdi-menu"></span>
                            </button>
                        </div>
                    </nav>
                    <!-- partial -->
                    <div class="main-panel">
                        <div class="content-wrapper pb-0">
                           

                                <div class="header-right d-flex flex-wrap mt-2 mt-sm-0">
                                    <?php
                                    if (isset($_GET['log'])){
                                        if ($_GET['log'] == 'yes')
                                            echo '<span>Le fichier est enregistré avec succè!!!</span>';
                                        else
                                            echo '<span>Veuillez verifier le format de votre fichier</span>';
                                    }

                                    ?>

                                </div>
                            
                            <?php
                            if (isset($_GET['page'])){
                                if ($_GET['page'] == "accueil")
                                    include ('vues/chaine/accueil.php');
                                if ($_GET['page'] == 'gerer')
                                    include ('vues/chaine/fichier.php');
                                if ($_GET['page'] == 'correspondant')
                                    include ('vues/chaine/correspondant.php');
                                if($_GET['page'] == 'msg')
                                    include ('vues/chaine/msg.php');
                                if($_GET['page'] == 'chat')
                                    include ('vues/chaine/chat.php');
                                if($_GET['page'] == 'video')
                                    include ('vues/chaine/video.php');
                            }else{
                                include ('vues/chaine/accueil.php');
                            }


                            ?>
                        </div>
                    </div>
                </div>
            </div>
            </div>

  <?php      }else
            header("Location:login.php");
 ?>


          <footer class="footer">
         

            <div>
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block"> Copyright © <?php echo date('Y'); 
              if($_GET['log'] == 'yes'){
                Query::deleteFile('assets/archivage', 'mp4', '0'); 
                Query::deleteFile('assets/archivage', 'mp3', '0');
              }

                 ?>  CentralData - <a href="#" >Tous droits reservés</a></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/jquery-bar-rating/jquery.barrating.min.js"></script>
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/vendors/flot/jquery.flot.js"></script>
    <script src="assets/vendors/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendors/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendors/flot/jquery.flot.fillbetween.js"></script>
    <script src="assets/vendors/flot/jquery.flot.stack.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <script src="assets/js/settings.js"></script>
    <script src="assets/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>
<?php
}else
header("Location:login.php");

?>