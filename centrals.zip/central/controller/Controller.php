<?php
	session_start();
	require_once('../models/Connexion.php');
	require_once('../models/Query.php');
	require_once('../models/Chaine.php');
	require_once('../models/Users.php');
    require_once('../models/AES.php');
    require_once('../models/Fichier.php');
    require_once('../models/Abonnement.php');
    require_once('../models/Chat.php');


	/****************************** Se connecter *****************************************/

	if (isset($_POST['btn_seconnecter'])) {
		$login = Chaine::key()->encrypt($_POST['email']);
		$password = md5($_POST['password']);

		$users = Users::seConnecter($login, $password);

		if ($users) {

            if ($password == md5('1234')) {
                header("Location:../modifier.php?pseudo=".$_POST['email']);
            }else{
                foreach ($users as $k) {
                $_SESSION['idusers'] = $k->getIdusers();
                $_SESSION['login'] = $k->getLogin();
                $_SESSION['role'] = $k->getRole();
                
            }

            header("Location:../index.php");

            }

			
				
		}else{
		    	header("Location:../index.php");
		}
	}

    if (isset($_POST['btn_modifier'])) {
        // code...
        $password = md5(Query::securisation($_POST['password']));
        $cpassword = md5(Query::securisation($_POST['cpassword']));
        $login = Chaine::key()->encrypt(Query::securisation($_POST['pseudo']));

        if ($password == $cpassword) {
            
            Query::CRUD("UPDATE `users` SET `password`='$password' WHERE `login`='$login'");
            $users = Users::seConnecter($login, $password);
            if ($users) {
                 foreach ($users as $k) {
                $_SESSION['idusers'] = $k->getIdusers();
                $_SESSION['login'] = $k->getLogin();
                $_SESSION['role'] = $k->getRole();
                
            }

            header("Location:../index.php");
            }

        }else{
            header("Location:../modifier.php?pseudo=".$_POST['pseudo']."&log=no");
        }
    }
	/****************************** creation de la chaine *****************************************/

	if (isset($_POST['btn_creer_chaine'])) {

        $name = Query::securisation($_POST['inputNomChaine']);
        $frequence_fm = Query::securisation($_POST['inputFrqRadio']);
        $frequence_uhf = Query::securisation($_POST['inputFrqTele']);
        $phone = Query::securisation($_POST['inputTelephone']);
        $adresse = Query::textArea($_POST['inputAdresse']);

        $_login = Chaine::key()->encrypt($name . '' . rand(10, 100));
        $_password = md5('1234');

        $extensions = array('.png', '.gif', '.jpg', '.jpeg', '.PNG', '.JPG', '.GIF', '.JPEG');

        if (isset($_FILES)) {
            $fichier = basename($_FILES['fichier']['name']);
            $fichier = strtr($fichier,
                'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
                'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
            $fichier = preg_replace('/([^.a-z0-9]+)/i', '-', $fichier);
            $extension = strrchr($_FILES['fichier']['name'], '.');

            $fichier_tmp = $_FILES['fichier']['tmp_name'];
            $destination = '../assets/picture/' . $fichier;

            if (in_array($extension, $extensions)) {
                $copy = move_uploaded_file($fichier_tmp, $destination);

                if ($copy) {

                    $users = new Users('', $_login, $_password, Chaine::key()->encrypt('chaine'));
                    $users->ajouter_users();
                    $idusers = $users->getId_users();

                    $chaine = new Chaine('', Chaine::key()->encrypt($name), Chaine::key()->encrypt($adresse), Chaine::key()->encrypt($fichier), '', Chaine::key()->encrypt($phone), '', Chaine::key()->encrypt($frequence_fm), Chaine::key()->encrypt($frequence_uhf), $idusers);
                    $chaine->ajouter_chaine();

                    header("Location:../index.php?page=accueil");
                }
            }
        }
    }

    if (isset($_POST['btn_modifier_chaine'])){
        $name = Query::securisation($_POST['inputNomChaine']);
        $frequence_fm = Query::securisation($_POST['inputFrqRadio']);
        $frequence_uhf = Query::securisation($_POST['inputFrqTele']);
        $phone = Query::securisation($_POST['inputTelephone']);
        $adresse = Query::textArea($_POST['inputAdresse']);
        $id = intval(Query::securisation($_POST['id']));
        (new Chaine($id, Chaine::key()->encrypt($name), Chaine::key()->encrypt($adresse), '', '', Chaine::key()->encrypt($phone), '', Chaine::key()->encrypt($frequence_fm), Chaine::key()->encrypt($frequence_uhf), ''))->modifier();
        header("Location:../index.php?page=accueil");
    }

    if (isset($_GET['delete'])){
        $idusers = intval(Query::securisation($_GET['delete']));
        Query::CRUD("DELETE FROM chaine WHERE idusers='$idusers'");
        Query::CRUD("DELETE FROM users WHERE idusers='$idusers'");
        header("Location:../index.php?page=gerer");
    }

    if (isset($_GET['page']))
    {
        session_destroy();
        header("Location:../index.php");
    }

    /**************************************** Gestion de fichier **********************************************/

    if (isset($_POST['btn_ajouter_video'])) {
        $titre = Fichier::key()->encrypt(Query::securisation($_POST['titre']));
        $commentaire = Fichier::key()->encrypt(Query::securisation($_POST['commentaire']));
        $extensions = array('.mp4', '.MP4', '.AVI', '.avi', '.MOV', '.mov');

        echo 'ok';
        if (isset($_FILES)) {
            $fichier = basename($_FILES['fichier']['name']);
            $fichier = strtr($fichier,
                'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
                'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
            $fichier = preg_replace('/([^.a-z0-9]+)/i', '-', $fichier);
            $extension = strrchr($_FILES['fichier']['name'], '.');

            $fichier_tmp = $_FILES['fichier']['tmp_name'];
            $destination = '../assets/archivage/' . $fichier;

            if (in_array($extension, $extensions)) {
                $copy = move_uploaded_file($fichier_tmp, $destination);
                Query::zipFile($destination);



                if ($copy) {
                    (new Fichier(null, $titre,Fichier::key()->encrypt($fichier), null, Fichier::key()->encrypt("video"), $_SESSION['idusers']))->ajouter();

                    header("Location:../index.php?log=yes");
                }else{
                    header("Location:../index.php?log=no");
                }
            }else{
                header("Location:../index.php?log=no");
            }
        }
    }

if (isset($_POST['btn_ajouter_audio'])) {
    $titre = Fichier::key()->encrypt(Query::securisation($_POST['titre']));
    $commentaire = Fichier::key()->encrypt(Query::securisation($_POST['commentaire']));
    $extensions = array('.mp3', '.MP3');

    if (isset($_FILES)) {
        $fichier = basename($_FILES['fichier']['name']);
        $fichier = strtr($fichier,
            'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
            'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
        $fichier = preg_replace('/([^.a-z0-9]+)/i', '-', $fichier);
        $extension = strrchr($_FILES['fichier']['name'], '.');

        $fichier_tmp = $_FILES['fichier']['tmp_name'];
        $destination = '../assets/archivage/' . $fichier;

        if (in_array($extension, $extensions)) {
            $copy = move_uploaded_file($fichier_tmp, $destination);
            Query::zipFile($destination);


            if ($copy) {
                (new Fichier(null, $titre,Fichier::key()->encrypt($fichier), null, Fichier::key()->encrypt("SON"), $_SESSION['idusers']))->ajouter();
                header("Location:../index.php?log=yes");
            }else{
                header("Location:../index.php?log=no");
            }
        }else{
            header("Location:../index.php?log=no");
        }
    }
}


    if (isset($_GET['idAbonnement'])){
        $idchaine = intval(Query::securisation($_GET['idAbonnement']));

        (new Abonnement(null, $_SESSION['idusers'], $idchaine, 0, null))->ajouter();
        header("Location:../index.php");
    }

    if (isset($_GET['btnConfirmer'])){
        $id = intval(Query::securisation($_GET['btnConfirmer']));
        Abonnement::confirmer($id);
        header("Location:../index.php");
    }


    if (isset($_GET['telecharger'])){
        $id = intval(Query::securisation($_GET['telecharger']));
        $file = Fichier::getVideo($id);
        $filesdir = '../assets/picture/';
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename='.$file);
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filesdir.$file)); //Absolute URL
        ob_clean();
        flush();
        readfile($filesdir.$file); //Absolute URL


    }

    if (isset($_GET['del'])) {
        // code...
        $id = intval(Query::securisation($_GET['del']));
        Fichier::delete($id);
       header("Location:../index.php?page=gerer"); 
    }

    if (isset($_GET['pause'])) {
        Query::deleteFile('../assets/archivage', 'mp3', '0');
        Query::deleteFile('../assets/archivage', 'mp4', '0'); 
        

        header("Location:../index.php");
    }

 


    /*********************************** Chat *************************************************/

    if (isset($_POST['btn_ajouter_msg']))
    {
        $idusers = intval(Query::securisation($_POST['idusers']));
        $msg = Chat::key()->encrypt(Query::textArea($_POST['msg']));
        (new Chat(null, $_SESSION['idusers'], $idusers, $msg, null))->ajouter();
        header("Location:../index.php?page=chat&idexp=".$idusers);

    }

    if (isset($_POST['btn_repo_chat']))
    {
        $id = intval(Query::securisation($_POST['id']));
        $msg = Chat::key()->encrypt(Query::textArea($_POST['msg']));
        (new Chat(null, $_SESSION['idusers'], $id, $msg, null))->ajouter();
        header("Location:../index.php?page=chat&idexp=".$id);
    }


