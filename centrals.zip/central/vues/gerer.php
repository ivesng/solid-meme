<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">LISTE DES CHAINES</h4>
            </p>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>LOGO</th>
                        <th>NOM</th>
                        <th>FREQUENCE RADIO</th>
                        <th>FREQUENCE TELE</th>
                        <th>ABONNE(E)S</th>
                         <th>FICHIER</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php

                    $chaine = Chaine::AFFICHER();
                    $t = 1;
                    if ($chaine){
                    foreach ($chaine as $i){ ?>


                    <tr>
                        <td class="py-1">
                         <?=$t++?>
                        </td>
                        <td class="py-1">
                            <img src="assets/picture/<?=$i->getLogo()?>" alt="image" />
                        </td>
                        <td><?=ucwords($i->getNom())?></td>
                        <td>
                            <?=$i->getFrequenceFm()?> MHZ
                        </td>
                        <td><?=$i->getFrequenceUhf()?> UHF</td>
                        <td><?=Abonnement::count($i->getIdusers())?></td>
                       <td><?=Fichier::countFichier($i->getIdusers())?></td>
                        <td> <a href="#" title="Modifier" data-toggle="modal" data-target="#myModal<?=$i->getId()?>"> <i class="mdi mdi-border-color star-color pr-1"></i> </a>
                            <div id="myModal<?=$i->getId()?>" class="modal fade" role="dialog">
                                <div class="modal-dialog modal-lg">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title"></h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="col-12 grid-margin stretch-card">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h4 class="card-title">Creer nouvelle chaine</h4>

                                                        <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">
                                                            <?php
                                                            $id = $i->getId();
                                                            $ch = Chaine::AFFICHER_ID($id);

                                                            if ($ch)
                                                            {
                                                                foreach ($ch as $j)
                                                                { ?>


                                                            <div class="form-group">
                                                                <label for="inputNomChaine">Nom de la chaine</label>
                                                                <input type="text" class="form-control" id="inputNomChaine" value="<?=$j->getNom()?>" placeholder="Nom de la chaine" name="inputNomChaine"/>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="inputFrqRadio">Frequence Radio</label>
                                                                <input type="text" class="form-control" value="<?=$j->getFrequenceFm()?>"  id="inputFrqRadio" placeholder="Frequence Radio" name="inputFrqRadio" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="exampleInputPassword4">Frequence Télé</label>
                                                                <input type="text" class="form-control" id="inputFrqTele" value="<?=$j->getFrequenceUhf()?>" placeholder="Frequence Télé" name="inputFrqTele" />
                                                            </div>

                                                            <div class="form-group" hidden>
                                                                <label>Logo</label>
                                                                <input type="hidden" name="id" value="<?=$id?>" class="form-control" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="inputTelephone">Téléphone</label>
                                                                <input type="text" class="form-control" id="inputTelephone" value="<?=$j->getPhone()?>" placeholder="Téléphone" name="inputTelephone" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="exampleTextarea1">Adresse</label>
                                                                <textarea
                                                                        class="form-control"
                                                                        name="inputAdresse" id="inputAdresse"
                                                                        rows="4"
                                                                        value="<?=$j->getDescription()?>"
                                                                ></textarea>
                                                            </div>
                                                            <button type="submit" name="btn_modifier_chaine" class="btn btn-primary mr-2"> Modifier </button>
                                                                <?php         }
                                                            }

                                                            ?>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>






                            <a href="controller/Controller.php?delete=<?=$i->getIdusers()?>" title="Supprimer"> <i class="mdi mdi-delete star-color pr-1"></i> </a></td>

                    </tr>

                    <?php }
                    } ?>





                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>