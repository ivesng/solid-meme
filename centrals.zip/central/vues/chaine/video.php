<?php Query::dezipper(Fichier::getVideo($_GET['idd'])); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">

            <video width="420" height="240" autoplay muted controls>
             <source src="assets/archivage/<?=Fichier::getVideo($_GET['idd'])?>" type="video/mp4">

        </video><br>

        <a href="controller/Controller.php?pause=1"  class="btn btn-primary" >Quitter!</a>
            
        </div>
    </div>
</div>

