<div class="page-header flex-wrap">
                                <div class="header-left">
                                    <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal"> Ajouter video </button>
                                    <div id="myModal" class="modal fade" role="dialog">
                                        <div class="modal-dialog modal-lg">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-12 grid-margin stretch-card">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h4 class="card-title">Ajouter Video</h4>

                                                                <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">
                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword4">Titre</label>
                                                                        <input type="text" class="form-control" id="inputFrqTele" placeholder="Titre" name="titre" />
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>Video</label>
                                                                        <input type="file" name="fichier" class="form-control" accept="video/mp4,video/x-m4v,video/*" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleTextarea1">Commentaire</label>
                                                                        <textarea
                                                                                class="form-control"
                                                                                name="commentaire" id="inputAdresse"
                                                                                rows="4"
                                                                        ></textarea>
                                                                    </div>
                                                                    <button type="submit" name="btn_ajouter_video" class="btn btn-primary mr-2"> Ajouter </button>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal2"> Ajouter Audio</button>
                                    <div id="myModal2" class="modal fade" role="dialog">
                                        <div class="modal-dialog modal-lg">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-12 grid-margin stretch-card">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h4 class="card-title">Ajouter Audio</h4>

                                                                <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">
                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword4">Titre</label>
                                                                        <input type="text" class="form-control" id="inputFrqTele" placeholder="Titre" name="titre"  />
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>Video</label>
                                                                        <input type="file" name="fichier" class="form-control" accept="audio/*/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleTextarea1">Commentaire</label>
                                                                        <textarea
                                                                                class="form-control"
                                                                                name="commentaire" id="inputAdresse"
                                                                                rows="4"
                                                                        ></textarea>
                                                                    </div>
                                                                    <button type="submit" name="btn_ajouter_audio" class="btn btn-primary mr-2"> Ajouter </button>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div><br><br>


<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">MES FICHIERS</h4>
            </p>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                      
                        <th>Titre</th>
                        <th>Type</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $id = $_SESSION['idusers'];

                    $chaine = Fichier::toDoList(Query::CRUD("SELECT * FROM fichier WHERE idchaine='$id'"));
                    $j = 1;
                    if ($chaine){
                        foreach ($chaine as $i){ ?>


                            <tr>

                                <td class="py-1">
                                    <?=$j++?>
                                </td>

                                <td>
                                    <?=ucwords($i->getTitre())?>
                                </td>
                                <td><?=ucwords($i->getType())?></td>

                                <td> <a href="controller/Controller.php?del=<?=$i->getId()?>" class="btn btn-primary ">Retirer </a>                 </td>

                            </tr>

                        <?php }
                    } ?>





                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
