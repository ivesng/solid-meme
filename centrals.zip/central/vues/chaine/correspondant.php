<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">LISTE DES FICHIERS PARTAGES</h4>
            </p>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Chaine</th>
                        <th>Titre</th>
                        <th>Type</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $id = $_SESSION['idusers'];
                    $chaine = Fichier::fileAbonnement();
              

                    $j = 1;
                    if ($chaine){
                        foreach ($chaine as $i){ ?>


                            <tr>
                                <td class="py-1">
                                    <?=$j++?>
                                </td>
                                <td><?=ucwords(Chaine::chaineNom($i->getIdchaine()))?></td>
                                <td>
                                    <?=ucwords($i->getTitre())?>
                                </td>
                                <td><?=ucwords($i->getType())?></td>

                                <td> <a href="index.php?page=video&idd=<?=$i->getId()?>" class="btn btn-primary " > Lire </a>
                                    <!-- Modal -->
                                    <div id="myModal3<?=$i->getId()?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">
                                            <?php
                                            $idd = $i->getId();
                                            $GLOBALS['titre'] = (Fichier::getVideo($idd));
                                            ?>
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <video width="420" height="240" autoplay muted controls>
                                                        <source src="assets/archivage/<?=Fichier::getVideo($idd)?>" type="video/mp4">

                                                    </video>
                                                </div>
                                                <div class="modal-footer">
                                                    <a  href="controller/Controller.php?pause=1"  class="btn btn-default" >Close <?php Fichier::getVideo($idd) ?></a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                </td>

                            </tr>

                        <?php }
                    } ?>





                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

    