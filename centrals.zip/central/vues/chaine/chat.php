<?php
    if (isset($_GET['page']))
    {
        $id = intval($_GET['idexp']);
        $chat = Chat::Affichers($id); ?>

<div class="page-header flex-wrap">
    <div class="header-left">
        <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal<?=$id?>"> Repondre </button>
        <div id="myModal<?=$id?>" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Repondre</h4>

                                    <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">



                                        <div class="form-group">
                                            <input value="<?=$id?>" type="hidden" name="id">
                                            <label for="exampleTextarea1"></label>
                                            <textarea
                                                    class="form-control"
                                                    name="msg" id="inputAdresse"
                                                    rows="4"
                                                    placeholder="Ecrit..."
                                            ></textarea>
                                        </div>
                                        <button type="submit" name="btn_repo_chat" class="btn btn-primary mr-2"> Envoyer </button>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>

    </div><br><br>

<?php

    if ($chat){
        foreach ($chat as $item){
            if ($item->getIdexp() != $_SESSION['idusers'])
            {
            ?>
            <div class="container">
                <img src="assets/picture/<?=Chaine::chaineLogo($item->getIdexp() )?>" alt="Avatar">
                <p><?=$item->getMsg()?></p>
                <span class="time-right"><?=$item->getDate()?></span>
            </div>
      <?php    } if($item->getIdexp() == $_SESSION['idusers']){ ?>
                <div class="container darker">
                    <img src="assets/picture/<?=Chaine::chaineLogo($item->getIdexp() )?>" alt="Avatar" class="right">
                    <p><?=$item->getMsg()?></p>
                    <span class="time-left"><?=$item->getDate()?></span>
                </div>
            <?php     }




      }
    }







    }

?>


<style>

    /* Chat containers */
.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

/* Darker chat container */
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

/* Clear floats */
.container::after {
  content: "";
  clear: both;
  display: table;
}

/* Style images */
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

/* Style the right image */
.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

/* Style time text */
.time-right {
  float: right;
  color: #aaa;
}

/* Style time text */
.time-left {
  float: left;
  color: #999;
}

</style>