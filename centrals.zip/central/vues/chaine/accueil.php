<div class="page-header flex-wrap">
                                <div class="header-left">
                                    <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal"> Ajouter video </button>
                                    <div id="myModal" class="modal fade" role="dialog">
                                        <div class="modal-dialog modal-lg">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-12 grid-margin stretch-card">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h4 class="card-title">Ajouter Video</h4>

                                                                <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">
                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword4">Titre</label>
                                                                        <input type="text" class="form-control" id="inputFrqTele" placeholder="Titre" name="titre" />
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>Video</label>
                                                                        <input type="file" name="fichier" class="form-control" accept="video/mp4,video/x-m4v,video/*" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleTextarea1">Commentaire</label>
                                                                        <textarea
                                                                                class="form-control"
                                                                                name="commentaire" id="inputAdresse"
                                                                                rows="4"
                                                                        ></textarea>
                                                                    </div>
                                                                    <button type="submit" name="btn_ajouter_video" class="btn btn-primary mr-2"> Ajouter </button>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal2"> Ajouter Audio</button>
                                    <div id="myModal2" class="modal fade" role="dialog">
                                        <div class="modal-dialog modal-lg">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="col-12 grid-margin stretch-card">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h4 class="card-title">Ajouter Audio</h4>

                                                                <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">
                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword4">Titre</label>
                                                                        <input type="text" class="form-control" id="inputFrqTele" placeholder="Titre" name="titre"  />
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label>Video</label>
                                                                        <input type="file" name="fichier" class="form-control" accept="audio/*/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleTextarea1">Commentaire</label>
                                                                        <textarea
                                                                                class="form-control"
                                                                                name="commentaire" id="inputAdresse"
                                                                                rows="4"
                                                                        ></textarea>
                                                                    </div>
                                                                    <button type="submit" name="btn_ajouter_audio" class="btn btn-primary mr-2"> Ajouter </button>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div><br><br>

<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">NEWS</h4>
                </p>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>NOM</th>
                            <th>ACTION</th>
                        </tr>
                        </thead>
                        <?php
                            $ab = Chaine::MYLIST(Query::CRUD("SELECT * FROM chaine WHERE  idusers  IN(
    SELECT idusers FROM abonnement WHERE status = 0 AND idchaine='".$_SESSION['idusers']."'
    )"));
                        if ($ab){
                            $j = 1;
                            foreach ($ab as $item){ ?>
                                <td><?=$j++?></td>
                                <td><?=ucwords($item->getNom())?></td>
                                <td><a href="controller/Controller.php?btnConfirmer=<?=$item->getIdusers()?>" class="col-lg-6 btn-primary" >Confirmer</a></td>
                    <?php        }
                        }

                        ?>

                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
    echo '<h3 class="col-lg-12">LISTE DES CHAINES</h3><br>';
    $chaine = Chaine::AFFICHER_CHAINE_ABONN();
    if ($chaine){
        foreach ($chaine as $i){ ?>
            <div class="col-sm-4 stretch-card grid-margin">
                <div class="card">
                    <div class="card-body p-0">
                        <img class="img-fluid w-100" src="assets/picture/<?=$i->getLogo()?>" alt="" />
                    </div>
                    <div class="card-body px-3 text-dark">
                        <div class="d-flex justify-content-between">
                            <p hidden class="text-muted font-13 mb-0">Pseudo : <?=Users::getLogin_users($i->getIdusers())?></p>

                        </div>
                        <h5 class="font-weight-semibold" > <?=ucwords($i->getNom())?></h5>
                        <div class="d-flex justify-content-between font-weight-semibold">
                            <p class="mb-0">
                                <i class="mdi mdi-radio star-color pr-1"></i><?=$i->getFrequenceFm()?> Mhz</p>
                            <p class="mb-0"> <i class="mdi mdi-television star-color pr-1"></i><?=$i->getFrequenceUhf()?>Mhz</p>

                        </div>
                      <?php
                            if (Abonnement::status($i->getIdusers()) == 0){ ?>
                                <a href="#" class="col-lg-6 btn-primary" >En attente</a>


                            <?php        }else if (Abonnement::existChaine($i->getIdusers())){ ?>
                                <a hidden href="controller/Controller.php?idAbonnement=<?=$i->getIdusers()?>" class="col-lg-6 btn-primary" >S'abonner</a>

                            <?php    }else{ ?>
                                <a href="controller/Controller.php?idAbonnement=<?=$i->getIdusers()?>" class="col-lg-6 btn-primary" >S'abonner</a>

                            <?php    }

                        ?>
                    </div>
                </div>
            </div>


        <?php       }

    }

    ?>

   <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">LISTE DES FICHIERS PARTAGES</h4>
            </p>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Chaine</th>
                        <th>Titre</th>
                        <th>Type</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $id = $_SESSION['idusers'];
                    $chaine = Fichier::fileAbonnement();
              

                    $j = 1;
                    if ($chaine){
                        foreach ($chaine as $i){ ?>


                            <tr>
                                <td class="py-1">
                                    <?=$j++?>
                                </td>
                                <td><?=ucwords(Chaine::chaineNom($i->getIdchaine()))?></td>
                                <td>
                                    <?=ucwords($i->getTitre())?>
                                </td>
                                <td><?=ucwords($i->getType())?></td>

                                <td> <a href="index.php?page=video&idd=<?=$i->getId()?>" class="btn btn-primary " > Lire </a>
                                    <!-- Modal -->
                                    <div id="myModal3<?=$i->getId()?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">
                                            <?php
                                            $idd = $i->getId();
                                            $_SESSION['titre'] = (Fichier::getVideo($idd));
                                            ?>
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <video width="420" height="240" autoplay muted controls>
                                                        <source src="assets/archivage/<?=Fichier::getVideo($idd)?>" type="video/mp4">

                                                    </video>
                                                </div>
                                                <div class="modal-footer">
                                                    <a  href="controller/Controller.php?pause=1"  class="btn btn-default" >Close</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                </td>

                            </tr>

                        <?php }
                    } ?>





                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

    <script>
        function delFile() {
            <?php Query::dezipper($_SESSION['titre']) ?>
               
       }
         
          

           

      
    </script>