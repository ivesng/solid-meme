<div class="page-header flex-wrap">
    <div class="header-left">
        <button class="btn btn-primary mb-2 mb-md-0 mr-2" data-toggle="modal" data-target="#myModal"> Nouveau message </button>
        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Nouveau message</h4>

                                    <form class="forms-sample"  action="controller/Controller.php" method="post" enctype="multipart/form-data">

                                        <div class="form-group">
                                            <label for="exampleInputPassword4">Destinataire</label>
                                            <select  class="form-control" name="idusers" >
                                                <?php
                                                $id = $_SESSION['idusers'];
                                                $ch = Abonnement::toDoList(Query::CRUD("SELECT * FROM `abonnement` WHERE (idusers='$id' OR idchaine='$id') "));
                                                if ($ch){
                                                    foreach ($ch As $i){
                                                        if ($i->getIdchaine() == $id){
                                                            echo '<option value="'.$i->getIdusers().'">'.Chaine::chaineNom($i->getIdusers()).'</option>';
                                                        }else{
                                                            echo '<option value="'.$i->getIdchaine().'">'.Chaine::chaineNom($i->getIdchaine()).'</option>';

                                                        }
                                                        ?>

                                                 <?php   }
                                                }
                                                ?>


                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleTextarea1"></label>
                                            <textarea
                                                    class="form-control"
                                                    name="msg" id="inputAdresse"
                                                    rows="4"
                                                    placeholder="Ecrit..."

                                            ></textarea>
                                        </div>
                                        <button type="submit" name="btn_ajouter_msg" class="btn btn-primary mr-2"> Envoyer </button>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>

    </div><br><br>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Message</h4>
            </p>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Expediteur</th>
                        <th>Date</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <?php
                            $j = 0;
                            $msg = Chat::Afficher($_SESSION['idusers']);
                            if ($msg){
                                foreach ($msg As $item){ ?>
                                <tr>
                                    <td><?=++$j?></td>
                                    <td><?=Chaine::chaineNom($item->getIdexp())?></td>
                                    <td><?=$item->getDate()?></td>
                                    <td><a href="index.php?page=chat&idexp=<?=$item->getIdexp()?>">Afficher</a></td>
                              </tr>
                        <?php        }

                            }
                        ?>

                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
