<?php


class Connexion
{

    public static function GetConnexion(){
        try{

            $pdo_options[PDO::ATTR_ERRMODE]=PDO::ERRMODE_EXCEPTION;
            $connexion  = new PDO('mysql:host=localhost;dbname=id17820320_data;charset=utf8mb4','id17820320_dataa','\tFH!s=ICF7mfZja',$pdo_options);
            return $connexion;

        }
        catch(Exception $e) {
            die('ERREUR : '. $e->getMessage());
        }

    }
}