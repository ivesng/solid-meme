<?php

	/**
	 * 
	 */
	class Affine
	{
		private $a;
		private $b;
		private $lettre;
		
		function __construct($a, $b)
		{
			$this->a = $a;
			$this->b = $b;
			$this->lettre = Array(
				'A'=>0, 'B'=>1,'C'=>2,'D'=>3,'E'=>4,'F'=>5,'G'=>6,'H'=>7,'I'=>8,'J'=>9,
				'K'=>10,'L'=>11,'M'=>12,'N'=>13,'O'=>14,'P'=>15,'Q'=>16,'R'=>17,'S'=>18,
				'T'=>19,'U'=>20,'V'=>21,'W'=>22,'X'=>23,'Y'=>24,'Z'=>25

			);

		}

		public function cryptage($mot){
			$tabY = array();
			$tabZ = array();
			$motCrypt = '';

			for ($i=0; $i < strlen($mot) ; $i++) { 
				// ax + b
				$tabY[] = ($this->a * $this->lettre[$mot[$i]]) + $this->b;
			}

			foreach ($tabY as $key) {
				// les modulos de 26 

				$tabZ[] = $key % 26;
			}

			foreach ($tabZ as $key => $valueZ) {
				foreach ($this->lettre as $key => $value) {
					if ($valueZ == $value) {
						$motCrypt = $motCrypt.$key;
					}
				}
			}

			return $motCrypt;
		}

		public function decrypter($mot){
			$tabY = array();
			$tabZ = array();
			$tabModulo = array();
			$motDecrypt = '';

			for ($i=0; $i < strlen($mot) ; $i++) { 
				// 
				$tabY[] = $this->lettre[$mot[$i]] - 3;
			}

			foreach ($tabY as $key) {
				// les multiplier par 23 

				$tabZ[] = $key * 23;
			}

			foreach ($tabZ as $key) {
				// les multiplier par 23 
				if ($key < 0) {
					// code...
					$tabModulo[] = 26 % $key;
				}else{
					$tabModulo[] = $key % 26;
				}
				
			}
			foreach ($tabModulo as $key => $valueZ) {
				foreach ($this->lettre as $key => $value) {
					if ($valueZ == $value) {
						$motDecrypt = $motDecrypt.$key;
					}
				}
			}

			return $tabModulo;


		}
	}