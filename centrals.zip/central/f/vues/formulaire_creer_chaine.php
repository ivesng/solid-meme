<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Création compte de la chaine</h3>
              
              </div>
              <!-- /.card-header -->
              <!-- form start -->

              <form action="controller/Controller.php" method="post">
                <div class="card-body">
                  <?php 
                  if (isset($_GET['log'])) {
                    if ($_GET['log'] == 'ok') { ?>
                      <p style="color: green;">Compte crée avec succès!</p>
                 <?php  }   }
              ?>
                  <div class="form-group">
                    <label for="inputNomChaine">Nom de la chaine</label>
                    <input type="text" class="form-control" id="inputNomChaine" placeholder="Nom de la chaine" name="inputNomChaine">
                  </div>
                  <div class="form-group">
                    <label for="inputFrqRadio">Frequence Radio</label>
                    <input type="text" class="form-control" id="inputFrqRadio" placeholder="Frequence Radio" name="inputFrqRadio">
                  </div>
                  <div class="form-group">
                    <label for="inputFrqTele">Frequence Télé</label>
                    <input type="text" class="form-control" id="inputFrqTele" placeholder="Frequence Télé" name="inputFrqTele">
                  </div>
                   <div class="form-group">
                    <label for="inputTelephone">Téléphone</label>
                    <input type="text" class="form-control" id="inputTelephone" placeholder="Téléphone" name="inputTelephone">
                  </div>
                  <div class="form-group">
                    <label for="inputAdresse">Adresse</label>
                    <p><textarea rows="5" cols="50" style="line-height: 105%;" onresize="2" name="inputAdresse" id="inputAdresse"></textarea></p>
                  </div>
              
                 
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="btn_creer_chaine" class="btn btn-primary">Créer</button>
                </div>
              </form>
            </div>