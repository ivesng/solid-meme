<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">LISTE DES CHAINES</h4>
            </p>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>LOGO</th>
                        <th>NOM</th>
                        <th>FREQUENCE RADIO</th>
                        <th>FREQUENCE TELE</th>
                        <th>ABONNE(E)S</th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php

                    $chaine = Chaine::AFFICHER();
                    $j = 1;
                    if ($chaine){
                    foreach ($chaine as $i){ ?>


                    <tr>
                        <td class="py-1">
                         <?=$j++?>
                        </td>
                        <td class="py-1">
                            <img src="assets/picture/<?=$i->getLogo()?>" alt="image" />
                        </td>
                        <td><?=ucwords($i->getNom())?></td>
                        <td>
                            <?=$i->getFrequenceFm()?> Mhz
                        </td>
                        <td><?=$i->getFrequenceUhf()?> Mhz</td>
                        <td>-</td>
                        <td> <a href="#" title="Modifier"> <i class="mdi mdi-border-color star-color pr-1"></i> </a>
                            <a href="controller/Controller.php?delete=<?=$i->getIdusers()?>" title="Supprimer"> <i class="mdi mdi-delete star-color pr-1"></i> </a></td>

                    </tr>

                    <?php }
                    } ?>





                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>