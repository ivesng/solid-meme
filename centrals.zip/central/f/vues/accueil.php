<div class="row">
    <?php

        $chaine = Chaine::AFFICHER();
        if ($chaine){
            foreach ($chaine as $i){ ?>
                <div class="col-sm-4 stretch-card grid-margin">
                    <div class="card">
                        <div class="card-body p-0">
                            <img class="img-fluid w-100" src="assets/picture/<?=$i->getLogo()?>" alt="" />
                        </div>
                        <div class="card-body px-3 text-dark">
                            <div class="d-flex justify-content-between">
                                <p class="text-muted font-13 mb-0">Pseudo : <?=Users::getLogin_users($i->getIdusers())?></p>

                            </div>
                            <h5 class="font-weight-semibold" > <?=ucwords($i->getNom())?></h5>
                            <div class="d-flex justify-content-between font-weight-semibold">
                                <p class="mb-0">
                                    <i class="mdi mdi-radio star-color pr-1"></i><?=$i->getFrequenceFm()?> Mhz</p>
                                <p class="mb-0"> <i class="mdi mdi-television star-color pr-1"></i><?=$i->getFrequenceUhf()?>Mhz</p>
                            </div>
                        </div>
                    </div>
                </div>


            <?php       }

        }

    ?>


</div>