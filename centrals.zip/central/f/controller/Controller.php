<?php
	session_start();
	require_once('../models/Connexion.php');
	require_once('../models/Query.php');
	require_once('../models/Chaine.php');
	require_once('../models/Users.php');
    require_once('../models/AES.php');
    require_once('../models/Fichier.php');


	/****************************** Se connecter *****************************************/

	if (isset($_POST['btn_seconnecter'])) {
		$login = Chaine::key()->encrypt($_POST['email']);
		$password = md5($_POST['password']);
        echo $password;
		$users = Users::seConnecter($login, $password);

		if ($users) {

			foreach ($users as $k) {
				$_SESSION['idusers'] = $k->getIdusers();
				$_SESSION['login'] = $k->getLogin();
				$_SESSION['role'] = $k->getRole();
				
			}

			header("Location:../index.php");
				
		}
	}
	/****************************** creation de la chaine *****************************************/

	if (isset($_POST['btn_creer_chaine'])) {

        $name = Query::securisation($_POST['inputNomChaine']);
        $frequence_fm = Query::securisation($_POST['inputFrqRadio']);
        $frequence_uhf = Query::securisation($_POST['inputFrqTele']);
        $phone = Query::securisation($_POST['inputTelephone']);
        $adresse = Query::textArea($_POST['inputAdresse']);

        $_login = Chaine::key()->encrypt($name . '' . rand(10, 100));
        $_password = md5('1234');

        $extensions = array('.png', '.gif', '.jpg', '.jpeg', '.PNG', '.JPG', '.GIF', '.JPEG');

        if (isset($_FILES)) {
            $fichier = basename($_FILES['fichier']['name']);
            $fichier = strtr($fichier,
                'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
                'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
            $fichier = preg_replace('/([^.a-z0-9]+)/i', '-', $fichier);
            $extension = strrchr($_FILES['fichier']['name'], '.');

            $fichier_tmp = $_FILES['fichier']['tmp_name'];
            $destination = '../assets/picture/' . $fichier;

            if (in_array($extension, $extensions)) {
                $copy = move_uploaded_file($fichier_tmp, $destination);

                if ($copy) {

                    $users = new Users('', $_login, $_password, Chaine::key()->encrypt('chaine'));
                    $users->ajouter_users();
                    $idusers = $users->getId_users();

                    $chaine = new Chaine('', Chaine::key()->encrypt($name), Chaine::key()->encrypt($adresse), Chaine::key()->encrypt($fichier), '', Chaine::key()->encrypt($phone), '', Chaine::key()->encrypt($frequence_fm), Chaine::key()->encrypt($frequence_uhf), $idusers);
                    $chaine->ajouter_chaine();

                    header("Location:../index.php?page=accueil");
                }
            }
        }
    }

    if (isset($_GET['delete'])){
        $idusers = intval(Query::securisation($_GET['delete']));
        Query::CRUD("DELETE FROM chaine WHERE idusers='$idusers'");
        Query::CRUD("DELETE FROM users WHERE idusers='$idusers'");
        header("Location:../index.php?page=gerer");
    }

    if (isset($_GET['page']))
    {
        session_destroy();
        header("Location:../index.php");
    }

    if (isset($_POST['btn_ajouter_video'])) {
        $titre = Fichier::key()->encrypt(Query::securisation($_POST['titre']));
        $commentaire = Fichier::key()->encrypt(Query::securisation($_POST['commentaire']));
        $extensions = array('.mp4', '.MP4', '.AVI', '.avi', '.MOV', '.mov');

        if (isset($_FILES)) {
            $fichier = basename($_FILES['fichier']['name']);
            $fichier = strtr($fichier,
                'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
                'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
            $fichier = preg_replace('/([^.a-z0-9]+)/i', '-', $fichier);
            $extension = strrchr($_FILES['fichier']['name'], '.');

            $fichier_tmp = $_FILES['fichier']['tmp_name'];
            $destination = '../assets/picture/' . $fichier;

            if (in_array($extension, $extensions)) {
                $copy = move_uploaded_file($fichier_tmp, $destination);

                if ($copy) {
                    (new Fichier(null, $titre,Fichier::key()->encrypt($fichier), null, Fichier::key()->encrypt("video"), $_SESSION['idusers']))->ajouter();
                    header("Location:../index.php?log=yes");
                }else{
                    header("Location:../index.php?log=no");
                }
            }else{
                header("Location:../index.php?log=no");
            }
        }
    }

if (isset($_POST['btn_ajouter_audio'])) {
    $titre = Fichier::key()->encrypt(Query::securisation($_POST['titre']));
    $commentaire = Fichier::key()->encrypt(Query::securisation($_POST['commentaire']));
    $extensions = array('.mp3', '.MP3');

    if (isset($_FILES)) {
        $fichier = basename($_FILES['fichier']['name']);
        $fichier = strtr($fichier,
            'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
            'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
        $fichier = preg_replace('/([^.a-z0-9]+)/i', '-', $fichier);
        $extension = strrchr($_FILES['fichier']['name'], '.');

        $fichier_tmp = $_FILES['fichier']['tmp_name'];
        $destination = '../assets/picture/' . $fichier;

        if (in_array($extension, $extensions)) {
            $copy = move_uploaded_file($fichier_tmp, $destination);

            if ($copy) {
                (new Fichier(null, $titre,Fichier::key()->encrypt($fichier), null, Fichier::key()->encrypt("SON"), $_SESSION['idusers']))->ajouter();
                header("Location:../index.php?log=yes");
            }else{
                header("Location:../index.php?log=no");
            }
        }else{
            header("Location:../index.php?log=no");
        }
    }
}

