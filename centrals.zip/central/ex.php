<?php
	include("header.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>


	<?php 
	$zip = new ZipArchive();
	$path = '.';
	$file = 'assets/archivage/MPR-SEMEKI-Clip-officiel-1-.zip';
	$res = $zip->open($file);
	if ($res === TRUE) {
		// code...
		$zip->extractTo($path);
		$zip->close();

		echo "Fichier $file extrait avec succès dans $path";
	}
	 /*if ($zip) {
           $zip_entry = zip_read($zip);
	echo str_replace('../', '', zip_entry_name($zip_entry));
	echo '<video  src="'.str_replace('../', '', zip_entry_name($zip_entry)).'" height="240" width="240" controls></video>';
	
	zip_close($zip); */


	?>

</body>
</html>